
class Bank
{
	private int accno;
	private String accName;
	private double salary;
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno=accno;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
}
public class encapdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
